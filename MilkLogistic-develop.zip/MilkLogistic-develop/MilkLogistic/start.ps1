﻿<#
  Запуск MilkLogistic одной командой.

    .\start.ps1              # реальный бэкенд + routing + db (+ OSRM, если данные готовы)
    .\start.ps1 -Build       # то же, но пересобрать образы (после правок кода)
    .\start.ps1 -Mock        # вместо бэкенда поднять заглушку API
    .\start.ps1 -Osrm        # принудительно поднять свой OSRM
    .\stop.ps1               # остановить всё

  Запускать из PowerShell. Права администратора не нужны.
  Docker Desktop должен быть установлен; если он выключен — скрипт попробует запустить.
#>
param(
    [switch]$Build,
    [switch]$Osrm,
    [switch]$Mock,
    [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Step([string]$text) { Write-Host "`n>> $text" -ForegroundColor Cyan }
function Ok([string]$text) { Write-Host "   [OK] $text" -ForegroundColor Green }
function Fail([string]$text) { Write-Host "   [!!] $text" -ForegroundColor Red }

# ---------------------------------------------------------------- 1. docker

Step "Ищу Docker"
$dockerExe = (Get-Command docker -ErrorAction SilentlyContinue).Source
if (-not $dockerExe) {
    foreach ($candidate in @(
        "$env:LOCALAPPDATA\Programs\DockerDesktop\resources\bin\docker.exe",
        "C:\Program Files\Docker\Docker\resources\bin\docker.exe"
    )) {
        if (Test-Path $candidate) { $dockerExe = $candidate; break }
    }
}
if (-not $dockerExe) {
    Fail "Docker не найден."
    Write-Host "   Установи Docker Desktop: https://www.docker.com/products/docker-desktop/"
    exit 1
}
$env:PATH = "$(Split-Path $dockerExe);$env:PATH"
Ok "docker: $(& $dockerExe --version)"

Step "Проверяю, запущен ли Docker Desktop"
function Test-DockerUp {
    # docker info пишет ошибку в stderr, а при ErrorActionPreference=Stop
    # PowerShell 5.1 считает это исключением. Поэтому глушим на время вызова.
    $previous = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    & $dockerExe info 1>$null 2>$null
    $code = $LASTEXITCODE
    $ErrorActionPreference = $previous
    return ($code -eq 0)
}

if (-not (Test-DockerUp)) {
    $desktop = @(
        "$env:LOCALAPPDATA\Programs\DockerDesktop\Docker Desktop.exe",
        "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $desktop) { Fail "Docker Desktop выключен, а найти его не удалось. Запусти вручную."; exit 1 }

    Write-Host "   Docker Desktop выключен, запускаю (это до 1-2 минут)..." -ForegroundColor Yellow
    Start-Process $desktop
    $ready = $false
    for ($i = 0; $i -lt 50; $i++) {
        Start-Sleep -Seconds 3
        if (Test-DockerUp) { $ready = $true; break }
        Write-Host "." -NoNewline
    }
    if (-not $ready) { Fail "Docker Desktop не поднялся за 2.5 минуты. Открой его вручную и запусти скрипт снова."; exit 1 }
}
Ok "Docker работает"

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Ok "создал .env из .env.example"
}

# ---------------------------------------------------------------- 2. compose

$composeArgs = @("-f", "docker-compose.yml")
if (-not $Mock) { $composeArgs += @("-f", "docker-compose.backend.yml") }

$osrmReady = Test-Path "infra/osrm/data/grodno.osrm"
if ($Osrm -and -not $osrmReady) {
    Fail "Нет данных OSRM. Сначала: .\infra\osrm\prepare.ps1"
    exit 1
}
if ($osrmReady) { $composeArgs += @("--profile", "geo") }

if ($Mock) { Step "Поднимаю стек с заглушкой API" }
elseif ($osrmReady) { Step "Поднимаю стек: реальный бэкенд + свой OSRM" }
else { Step "Поднимаю стек: реальный бэкенд (OSRM не подготовлен)" }

$upArgs = $composeArgs + @("up", "-d")
if ($Build) { $upArgs += "--build" }
& $dockerExe compose @upArgs
if ($LASTEXITCODE -ne 0) { Fail "docker compose завершился с ошибкой. Смотри вывод выше."; exit 1 }

# ---------------------------------------------------------------- 3. ожидание

Step "Жду, пока сервисы ответят"
$api = $false
$routing = $false
for ($i = 0; $i -lt 30; $i++) {
    if (-not $api) {
        try { Invoke-RestMethod "http://localhost:8000/api/health" -TimeoutSec 3 | Out-Null; $api = $true } catch { }
    }
    if (-not $routing) {
        try { Invoke-RestMethod "http://localhost:8100/api/health" -TimeoutSec 5 | Out-Null; $routing = $true } catch { }
    }
    if ($api -and $routing) { break }
    Start-Sleep -Seconds 2
    Write-Host "." -NoNewline
}

if ($api) { Ok "API отвечает" } else { Fail "API не отвечает: docker compose logs api" }
if ($routing) { Ok "сервис маршрутизации отвечает" } else { Fail "routing не отвечает: docker compose logs routing" }

# ---------------------------------------------------------------- 4. итог

Step "Готово"
Write-Host ""
Write-Host "   Интерфейс (фронтенд) .... http://localhost:8080   <- карта и маршруты"
Write-Host "   Проверка расчётов ....... http://localhost:8000/   <- отчёт бэкенда"
Write-Host "   API ..................... http://localhost:8000/docs"
Write-Host "   Маршрутизация ........... http://localhost:8100/api/health"
Write-Host ""

try {
    $health = Invoke-RestMethod "http://localhost:8100/api/health" -TimeoutSec 15
    if ($health.osrm.reachable) {
        Ok "OSRM доступен: $($health.osrm.base_url), $($health.osrm.latency_ms) мс"
    } else {
        Write-Host "   [!!] OSRM недоступен. Если нужен офлайн-режим:" -ForegroundColor Yellow
        Write-Host "        .\infra\osrm\prepare.ps1" -ForegroundColor Yellow
        Write-Host "        .\start.ps1 -Osrm" -ForegroundColor Yellow
    }
} catch {
    Write-Host "   [!!] не смог проверить OSRM" -ForegroundColor Yellow
}

Write-Host "   Проверка целиком: .\infra\preflight.ps1" -ForegroundColor DarkGray
Write-Host "   Остановить:       .\stop.ps1" -ForegroundColor DarkGray
if (-not $NoBrowser) { Start-Process "http://localhost:8080" }
